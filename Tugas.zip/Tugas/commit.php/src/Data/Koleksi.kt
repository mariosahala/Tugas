package Data

interface Koleksi {
    fun showResult(msg :String)
}